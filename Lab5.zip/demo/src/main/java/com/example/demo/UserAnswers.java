package com.example.demo;

import java.util.Map;

public class UserAnswers {

    private Map<Integer, String> answers;

    public UserAnswers() {
    }

    public Map<Integer, String> getAnswers() {
        return answers;
    }

    public void setAnswers(Map<Integer, String> answers) {
        this.answers = answers;
    }
}
